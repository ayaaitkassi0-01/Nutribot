from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from backend.services.ai_service import generate_meal_plan
app = FastAPI()

# CORS (important)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# Servir les fichiers statiques
app.mount("/static", StaticFiles(directory="frontend"), name="static")

# Page HTML principale
@app.get("/")
def serve_index():
    return FileResponse("frontend/index.html")

# ROUTE POST DU FORMULAIRE
@app.post("/api/generate")
async def generate(data: dict):
    print("✅ Données reçues :", data)
    plan = generate_meal_plan(data)
    return {
        "meal_plan": plan
    }
