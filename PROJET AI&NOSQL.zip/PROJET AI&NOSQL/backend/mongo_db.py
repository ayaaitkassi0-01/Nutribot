from pymongo import MongoClient
import os
from dotenv import load_dotenv

load_dotenv()

# URL MongoDB (depuis .env ou localhost par défaut)
MONGO_URL = os.getenv("MONGO_URL", "mongodb://localhost:27017")
client = MongoClient(MONGO_URL)

# Base où se trouvent réellement tes aliments
db = client["nutribot_nosql"]

# Collections principales
users_collection = db["users"]          # utilisateurs
meal_plans_collection = db["meal_plans"]  # plans alimentaires
foods_collection = db["foods"]           # aliments

print("MongoDB connecté 🔥")
