import os
import openai
from backend.mongo_db import foods_collection
from dotenv import load_dotenv
import random
import json

load_dotenv()
openai.api_key = os.getenv("OPENAI_API_KEY")

print("AI_SERVICE ACTIF ✅")

def generate_meal_plan(user):
    name = user.get("name")
    age = user.get("age")
    weight = user.get("weight")
    height = user.get("height")
    gender = user.get("gender")
    activity_level = user.get("activity_level")
    goal = user.get("goal")

    prompt = f"""
    Tu es un coach nutritionnel IA. 
    Prépare un plan alimentaire personnalisé pour un utilisateur avec les informations suivantes :
    Nom: {name}, Âge: {age}, Poids: {weight}kg, Taille: {height}cm, Sexe: {gender}, 
    Niveau d'activité: {activity_level}, Objectif: {goal}.
    Donne-moi 4 repas : petit-déjeuner, déjeuner, snack, dîner, avec des aliments réalistes.
    Ajoute un petit conseil nutritionnel à la fin.
    Réponds sous format JSON :
    {{
      "breakfast": "...",
      "lunch": "...",
      "snack": "...",
      "dinner": "...",
      "tips": "..."
    }}
    """

    try:
        response = openai.chat.completions.create(
            model="gpt-3.5-turbo",
            messages=[{"role": "user", "content": prompt}],
            temperature=0.7
        )
        content = response.choices[0].message.content
        meal_plan = json.loads(content)
        return meal_plan

    except Exception as e:
        print("❌ Erreur LLM, fallback MongoDB :", e)
        return generate_meal_plan_from_db(user)

def generate_meal_plan_from_db(user):
    meal_plan = {}
    meals = {"breakfast": 3, "lunch": 3, "snack": 2, "dinner": 2}

    for meal, count in meals.items():
        foods = list(foods_collection.find({"meal": meal}))
        if not foods:
            meal_plan[meal] = "Aucun aliment disponible"
        else:
            selected = random.sample(foods, min(count, len(foods)))
            meal_plan[meal] = " + ".join(food["name"] for food in selected)

    meal_plan["tips"] = "💧 Boire 1,5L d'eau et respecter les portions."
    return meal_plan
