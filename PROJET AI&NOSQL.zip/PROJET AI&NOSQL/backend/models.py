from sqlalchemy import Column, Integer, String, Float, DateTime
from sqlalchemy.ext.declarative import declarative_base
from datetime import datetime

Base = declarative_base()

class User(Base):
    __tablename__ = 'users'

    id = Column(Integer, primary_key=True)
    name = Column(String(100), nullable=False, unique=True)
    age = Column(Integer, nullable=False)
    weight = Column(Float, nullable=False)
    height = Column(Float, nullable=False)
    gender = Column(String(10), nullable=False)  # "male" or "female"
    activity_level = Column(String(20), nullable=False)  # "sedentary", "light", "moderate", "active", "very_active"
    goal = Column(String(50), nullable=False)  # "lose_weight", "maintain", "gain_weight"
    created_at = Column(DateTime, default=datetime.utcnow)

    def __repr__(self):
        return f"<User(name={self.name}, age={self.age})>"