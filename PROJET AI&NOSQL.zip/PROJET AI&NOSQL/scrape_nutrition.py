import requests
import csv

URL = "https://world.openfoodfacts.org/cgi/search.pl"

params = {
    "search_terms": "",
    "search_simple": 1,
    "action": "process",
    "json": 1,
    "page_size": 200
}

response = requests.get(URL, params=params)
data = response.json()

foods = []

for product in data.get("products", []):
    name = product.get("product_name")
    nutriments = product.get("nutriments", {})
    category = product.get("categories", "")

    if not name:
        continue

    foods.append([
        name,
        nutriments.get("energy-kcal_100g", ""),
        nutriments.get("proteins_100g", ""),
        nutriments.get("fat_100g", ""),
        nutriments.get("carbohydrates_100g", ""),
        nutriments.get("fiber_100g", ""),
        category
    ])

with open("nutrition.csv", "w", newline="", encoding="utf-8") as f:
    writer = csv.writer(f)
    writer.writerow([
        "food_name",
        "energy_kcal",
        "proteins_g",
        "fat_g",
        "carbohydrates_g",
        "fiber_g",
        "category"
    ])
    writer.writerows(foods)

print("✅ Base nutrition.csv créée avec", len(foods), "aliments")
