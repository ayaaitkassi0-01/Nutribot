document.addEventListener("DOMContentLoaded", () => {
    const form = document.getElementById("userForm");
    const resultDiv = document.getElementById("result");

    form.addEventListener("submit", async (e) => {
        e.preventDefault();

        const formData = new FormData(form);
        const data = Object.fromEntries(formData.entries());

        console.log("📤 Données envoyées :", data);

        try {
            const response = await fetch("/api/generate", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify(data)
            });

            const result = await response.json();
            console.log("📥 Réponse reçue :", result);

            // ✅ Affichage complet avec sexe, activité et objectif
            resultDiv.innerHTML = `
                <h2>✅ Plan alimentaire généré</h2>
                <h3>Informations utilisateur</h3>
                <p><strong>Nom :</strong> ${data.name}</p>
                <p><strong>Âge :</strong> ${data.age}</p>
                <p><strong>Sexe :</strong> ${data.gender}</p>
                <p><strong>Niveau d'activité :</strong> ${data.activity_level}</p>
                <p><strong>Objectif :</strong> ${data.goal}</p>

                <h3>Plan alimentaire</h3>
                <p><strong>Petit-déjeuner :</strong> ${result.meal_plan.breakfast}</p>
                <p><strong>Déjeuner :</strong> ${result.meal_plan.lunch}</p>
                <p><strong>Snack :</strong> ${result.meal_plan.snack}</p>
                <p><strong>Dîner :</strong> ${result.meal_plan.dinner}</p>
                <p><strong>Conseils :</strong> ${result.meal_plan.tips}</p>
            `;

        } catch (error) {
            console.error(error);
            resultDiv.innerHTML = "❌ Erreur lors de la génération";
        }
    });
});
