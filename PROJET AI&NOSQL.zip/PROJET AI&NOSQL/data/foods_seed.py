from pymongo import MongoClient

# Connexion à MongoDB
client = MongoClient("mongodb://localhost:27017")
db = client["nutribot_nosql"]
foods_collection = db["foods"]

# On vide d'abord la collection pour éviter les doublons
foods_collection.delete_many({})

# Liste des aliments par type de repas
foods = [
    # Breakfast
    {"name": "Oeufs brouillés", "meal": "breakfast", "calories": 150},
    {"name": "Pain complet", "meal": "breakfast", "calories": 100},
    {"name": "Yaourt nature", "meal": "breakfast", "calories": 120},
    {"name": "Flocons d'avoine", "meal": "breakfast", "calories": 130},
    {"name": "Smoothie fruité", "meal": "breakfast", "calories": 180},

    # Lunch
    {"name": "Salade de poulet", "meal": "lunch", "calories": 300},
    {"name": "Riz complet et légumes", "meal": "lunch", "calories": 350},
    {"name": "Quinoa aux légumes", "meal": "lunch", "calories": 320},
    {"name": "Sandwich au thon", "meal": "lunch", "calories": 280},
    {"name": "Soupe de lentilles", "meal": "lunch", "calories": 250},

    # Snack
    {"name": "Fromage blanc", "meal": "snack", "calories": 120},
    {"name": "Fruits secs", "meal": "snack", "calories": 160},
    {"name": "Pommes", "meal": "snack", "calories": 80},
    {"name": "Bananes", "meal": "snack", "calories": 90},
    {"name": "Noix", "meal": "snack", "calories": 200},

    # Dinner
    {"name": "Soupe de légumes", "meal": "dinner", "calories": 150},
    {"name": "Omelette", "meal": "dinner", "calories": 200},
    {"name": "Poisson vapeur", "meal": "dinner", "calories": 220},
    {"name": "Légumes sautés", "meal": "dinner", "calories": 120},
    {"name": "Poulet rôti", "meal": "dinner", "calories": 250},
    {"name": "Pâtes complètes", "meal": "dinner", "calories": 300},
]

# Insertion dans MongoDB
result = foods_collection.insert_many(foods)
print(f"{len(result.inserted_ids)} aliments insérés avec succès ✅")
