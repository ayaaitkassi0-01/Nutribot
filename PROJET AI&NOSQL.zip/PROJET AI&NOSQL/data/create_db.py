# backend/create_db.py
from backend.database import Base, engine
from backend.models import User

# Créer toutes les tables
Base.metadata.create_all(bind=engine)
print("Base de données créée avec succès!")