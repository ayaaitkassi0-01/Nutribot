from pymongo import MongoClient
from bson.objectid import ObjectId

# Connexion à MongoDB
client = MongoClient("mongodb://localhost:27017")
db = client["nutribot_nosql"]  # utilise ta base "nutribot_nosql"
users_collection = db["users"]

# On supprime tous les utilisateurs existants (optionnel pour clean)
users_collection.delete_many({})

# Création d'un utilisateur test
user = {
    "_id": ObjectId("6951b0032c5fab9811620542"),  # Même ID que ton test
    "name": "ooo",
    "age": 20,
    "weight": 50,
    "height": 170,
    "gender": "femme",
    "activity_level": "faible",
    "goal": "gagner du poids"
}

users_collection.insert_one(user)
print("Utilisateur inséré ✅")
