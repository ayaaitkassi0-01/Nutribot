# populate_mongo.py
import random
from datetime import datetime
from pymongo import MongoClient

# 🔹 Connexion à MongoDB
client = MongoClient("mongodb://localhost:27017")
db = client["nutribot_nosql"]
collection = db["meal_plans"]

# 🔹 Listes pour générer des profils variés
genders = ["male", "female"]
activities = ["sedentary", "light", "moderate", "active", "very_active"]
goals = ["lose_weight", "maintain", "gain_weight"]

# 🔹 Exemple d’aliments pour chaque catégorie
breakfast_foods = ["Pain + lait", "Céréales + yaourt", "Omelette + toast", "Smoothie + fruits"]
lunch_foods = ["Poulet + riz", "Poisson + quinoa", "Steak + légumes", "Tofu + pâtes"]
snack_foods = ["Yaourt + fruits secs", "Fruits", "Barre protéinée", "Noix + smoothie"]
dinner_foods = ["Poisson + légumes", "Poulet + salade", "Steak + pommes de terre", "Légumes + quinoa"]
tips_list = [
    "Boire beaucoup d’eau",
    "Éviter les boissons sucrées",
    "Manger lentement",
    "Prendre des protéines après l’entraînement"
]

# 🔹 Fonction pour calculer BMR
def calculate_bmr(weight, height, age, gender):
    if gender == "male":
        return 10*weight + 6.25*height - 5*age + 5
    else:
        return 10*weight + 6.25*height - 5*age - 161

# 🔹 Génération des profils
profiles = []
for i in range(1, 51):  # 50 profils
    age = random.randint(15, 60)
    weight = random.randint(45, 100)
    height = random.randint(150, 190)
    gender = random.choice(genders)
    activity_level = random.choice(activities)
    goal = random.choice(goals)

    imc = round(weight / ((height/100)**2), 2)
    bmr = round(calculate_bmr(weight, height, age, gender))
    
    # multiplier selon activité
    activity_multipliers = {
        "sedentary": 1.2,
        "light": 1.375,
        "moderate": 1.55,
        "active": 1.725,
        "very_active": 1.9
    }
    total_calories = round(bmr * activity_multipliers[activity_level])

    meal_plan = {
        "breakfast": f"{random.choice(breakfast_foods)} → {round(total_calories*0.2)} kcal",
        "lunch": f"{random.choice(lunch_foods)} → {round(total_calories*0.35)} kcal",
        "snack": f"{random.choice(snack_foods)} → {round(total_calories*0.15)} kcal",
        "dinner": f"{random.choice(dinner_foods)} → {round(total_calories*0.3)} kcal",
        "tips": random.choice(tips_list)
    }

    profile_doc = {
        "user_id": i,
        "profile": {
            "age": age,
            "weight": weight,
            "height": height,
            "gender": gender,
            "activity_level": activity_level,
            "goal": goal
        },
        "metrics": {
            "imc": imc,
            "bmr": bmr,
            "total_calories": total_calories
        },
        "meal_plan": meal_plan,
        "created_at": datetime.utcnow()
    }

    profiles.append(profile_doc)

# 🔹 Insérer tous les profils dans MongoDB
collection.insert_many(profiles)
print(f"{len(profiles)} profils insérés dans la base nutribot_nosql !")
